V prípade, že sa chystáte používať "matlabovskú" verziu tejto aplikácie:

1. Spustite skript s názvom analyza_termogramov.mlapp poprípade balík s názvom Aplikacia_pre_analyzu_termogramov_matlab.mlappinstall

2. V úvodnej karte si zvoľte typ analýzy, ktorý chcete uskutočniť. Na výber je všeobecná analýza pre 1 termogram a záťažová analýza pre 2-5 termogramov.

3. Podľa typu zvolenej analýzy načítajte vyššie spomenutý požadovaný počet termogramov z pamäte počítača. O úspešnom, resp. neúspešnom načítaní termogramov budete upozornený. 

4. Podrobný návod ako následne pracovať s aplikáciou sa nachádza v tomto priečinku spolu s ostatnými súbormi pod názvom: návod_záťažová_analýza.txt alebo návod_všeobecná_analýza.txt.

5. Po zobrazení výsledkov máte možnosť si ich vyexportovať ako csv. súbory a následne otvoriť napríklad v programe Excel.
   Popis generovaných súborov sa nachádza na konci tohto textového súboru.
   Súbory sa ukladajú do rovnakého priečinka, z ktorého boli na začiatku termogramy načítané.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

V prípade, že sa chystáte používať desktopovú verziu tejto aplikácie:

1. Nainštalujte si MATLAB Runtime, ktorého inštalácia sa automaticky spustí po otvorení súboru v sekcií for_redistribution: MyAppInstaller_web.exe

2. Po nainštalovaní by sa mala aplikácia uložiť na plochu pod názvom: Aplikacia_pre_analyzu_temogramov.exe. Pri ďalšom spúštaní aplikácie stačí spúšťať aplikáciu z plochy. Ak sa Vám nevytvoril odkaz na ploche 
spustie aplikáciu prosím z druhého priečinka: for_redistribution_files_only. 

3. Dvojitým kliknutím na jej odkaz na ploche alebo v spomenutom priečinku sa aplikácia spustí (Po inštalácií funguje aj offline).

4. V úvodnej karte si zvoľte typ analýzy, ktorý chcete uskutočniť. Na výber je všeobecná analýza pre 1 termogram a záťažová analýza pre 2-5 termogramov.

5. Podľa typu zvolenej analýzy načítajte vyššie spomenutý požadovaný počet termogramov z pamäte počítača. O úspešnom, resp. neúspešnom načítaní termogramov budete upozornený. 

6. Podrobný návod ako následne pracovať s aplikáciou sa nachádza v v tomto priečinku spolu s ostatnými súbormi pod názvom: návod_záťažová_analýza.txt alebo návod_všeobecná_analýza.txt.

7. Po zobrazení výsledkov máte možnosť si ich vyexportovať ako csv. súbory a následne otvoriť napríklad v programe Excel. 
   Súbory sa ukladajú do rovnakého priečinka, z ktorého boli na začiatku termogramy načítané.
   Popis generovaných súborov sa nachádza na konci tohto textového súboru.
 
-------------------------------------------------------------------------------------------------------------------------------------

Výsledky: Pri generovaní názvov súborov je v každom jednom názve za posledným podtržítkom vypísaný dátum a čas vytvorenia súboru, pre odlíšenie vytváraných súborov. 
a) V prípade všeobecnej analýzy sú generované dva súbory: 
'Analýza_1termogram_ROI_.csv', kde sa nachádzajú všetky teplotné dáta z vykreslených ROI. 
'Analýza_1termogramu_tabulka_csv', ktorý obsahuje tabuľku s teplotnými výsledkami z ROI.

b) V prípade záťažovej analýzy sú generované tri súbory: 
Prvý súbor je 'Záťažová_analýza_ROI_.csv',kde sa nachádzajú všetky teplotné dáta (podľa počtu termogramov) z vykreslených ROI. 
Ďalej súbor 'Záťažová_analýza_asymetria_.csv', ktorý obsahuje tabuľku hodnotiaciu teplotnú asymetriu medzi dom. a nedom. končatinou.
A nakoniec súbor'Záťažová_analýza_tabulka_.csv', ktorý obsahuje tabuľku s min,max,medián a primernou teplotou z ROI z dom. a nedom. končatiny z každého termogramu.

----------------------------------------------------------------------------------------------------------------------------------------------
Poznámka autorky: Výsledky, ktoré sa nachádzajú v prílohe nemajú rovnaké pomenovanie a majú formálne inak rozložený obsah, pretože boli uskutočnené pred záverečnými úpravami aplikácie a 
taktiež je ich názov pozmenený tak aby sa dalo rozoznať, ku ktorej probandky výsledky patria, napríklad ako: Záťažová_analýza_tabulka_1p_nohy.




